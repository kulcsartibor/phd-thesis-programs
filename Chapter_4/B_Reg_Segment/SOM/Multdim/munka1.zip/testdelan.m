  R = rand(10,5);
  N = delaunay(R)
  isdln(N,R)
