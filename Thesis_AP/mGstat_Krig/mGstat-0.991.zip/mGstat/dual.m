function dual=dual()
load dual

