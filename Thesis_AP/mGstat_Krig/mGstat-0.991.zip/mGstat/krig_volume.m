% krig_volume : kriging with volume average data
%
% See hansen et. al. 2005.
%
function kriging_volume()
  