% mgstat_clean : clean up temporary files from visim, sgems, fast

visim_clean;
fast_fd_clean;
sgems_clean;
